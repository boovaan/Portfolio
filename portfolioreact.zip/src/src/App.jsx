import Portfolio from "./Portfolio.jsx";
function App() {
  return (
    <Portfolio />
  
  );
}
export default App;